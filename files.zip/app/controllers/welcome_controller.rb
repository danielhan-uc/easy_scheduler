class WelcomeController < ApplicationController
  def index
    render :index
  end
end
